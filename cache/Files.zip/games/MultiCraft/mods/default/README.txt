Minetest 0.4 mod: default
==========================

License of source code:
-----------------------
Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html

License of media (sounds)
--------------------------------------
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

Authors of media files
-----------------------
MirceaKitsune (WTFPL):
  character.x

Glass breaking sounds (CC BY 3.0):
  1: http://www.freesound.org/people/cmusounddesign/sounds/71947/
  2: http://www.freesound.org/people/Tomlija/sounds/97669/
  3: http://www.freesound.org/people/lsprice/sounds/88808/

Mito551 (sounds) (CC BY-SA):
  default_dig_choppy.ogg
  default_dig_cracky.ogg
  default_dig_crumbly.1.ogg
  default_dig_crumbly.2.ogg
  default_dig_dig_immediate.ogg
  default_dig_oddly_breakable_by_hand.ogg
  default_dug_node.1.ogg
  default_dug_node.2.ogg
  default_grass_footstep.1.ogg
  default_grass_footstep.2.ogg
  default_grass_footstep.3.ogg
  default_gravel_footstep.1.ogg
  default_gravel_footstep.2.ogg
  default_gravel_footstep.3.ogg
  default_gravel_footstep.4.ogg
  default_grass_footstep.1.ogg
  default_place_node.1.ogg
  default_place_node.2.ogg
  default_place_node.3.ogg
  default_place_node_hard.1.ogg
  default_place_node_hard.2.ogg
  default_snow_footstep.1.ogg
  default_snow_footstep.2.ogg
  default_hard_footstep.1.ogg
  default_hard_footstep.2.ogg
  default_hard_footstep.3.ogg
  default_sand_footstep.1.ogg
  default_sand_footstep.2.ogg
  default_wood_footstep.1.ogg
  default_wood_footstep.2.ogg
  default_dirt_footstep.1.ogg
  default_dirt_footstep.2.ogg
  default_glass_footstep.ogg
