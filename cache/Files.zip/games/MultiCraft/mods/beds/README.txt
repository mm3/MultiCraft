Minetest mod "Beds"
=======================
version: 1.1


License of source code: WTFPL
-----------------------------
author: BlockMen (2013)
original author: PilzAdam

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


--USING the mod--
------------------

This mods implements Beds like known from Minecraft. You can use them to sleep at night to skip the time or to prevent attacks by evil mobs.


To sleep you have to "rightclick" on your bed. You can only sleep at night and get noticed when it is too early.

After dying the player will respawn at the last bed he has slept.