MultiCraft by MoNTE48
Based on overcraft_origins
A Minecraft-like game for the Minetest game engine [overcraft_origins]
======================================================================

License of source code
----------------------
Copyright (C) 2013 jojoa1997
See README.txt in each mod directory for information about other authors.

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

License of media (textures and sounds)
--------------------------------------
Copyright (C) 2013 Vattic

http://www.minecraftforum.net/topic/72747-/

Vattic's Terms:
	Things that are fine:
	- Use as placeholders.
	- Using as many textures as you've made yourself.
	- Using the items or paintings.
	- Use as base for mod textures.

	Requirements:
	- Give clear credit.
	- Link back to the Faithful 32x32 thread.
	- Be honest about what you are using.
	- No money making links.

	On remix/tweaked packs:
	- Let's Players can share a modified copy with fans.
	- Adventure map makers can provide modified copy to go along with it.

	If either of the above apply:
	- You must distribute through YouTube video descriptions or your series'/map's forum topic and not create a separate thread for the pack.
	- To avoid people uploading a video just so they can upload a copy of the pack Let's Players must have a decent number of videos that use the pack and a decent number of subscribers.

	Finally:
	- If I decide I don't want you using stuff from the pack then that is final. This will only be the case in unusual circumstances.
	- These guidelines can be changed at any time.

See README.txt in each mod directory for information about other authors.

License of menu/header.png
Copyright (C) 2013 jojoa1997 CC BY-SA 3.0

